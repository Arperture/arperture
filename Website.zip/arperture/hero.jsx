/* Arperture landing — Nav + Hero (three switchable layouts) */

function Nav({ onStart }) {
  const links = [
    ["What we make", "work"],
    ["Why us", "why"],
    ["Process", "how"],
    ["Work", "selected"],
    ["Contact", "contact"],
  ];
  const go = (id) => (e) => {
    e.preventDefault();
    const el = document.getElementById(id);
    if (el) window.scrollTo({ top: el.offsetTop - 70, behavior: "smooth" });
  };
  return (
    <nav className="nav">
      <div className="nav-inner">
        <a className="brand" href="#top" onClick={go("top")}>
          <Mark size={32} />
          <span className="brand-name">Arperture<b>.</b></span>
        </a>
        <ul className="nav-links">
          {links.map(([label, id]) => (
            <li key={id}><a href={"#" + id} onClick={go(id)}>{label}</a></li>
          ))}
        </ul>
        <div className="nav-right">
          <Button variant="coral" size="sm" onClick={onStart}>Start a project</Button>
        </div>
      </div>
    </nav>
  );
}

const HERO_COPY = {
  kicker: "Now booking · Q3 · Arcola, VA",
  title: (
    <>
      Your story, <em>at 24&nbsp;frames<br />a second.</em>
    </>
  ),
  lead:
    "We blend the precision of AI with the soul of cinema — film-grade video, sound design, and branded stories for brands, artists & storytellers.",
  meta: ["Veo 3.1 · Sound · Edit", "Cinematic dark", "Boutique studio"],
};

function HeroButtons({ onStart, onReel }) {
  return (
    <div className="btn-row">
      <Button variant="coral" size="lg" onClick={onStart}>Start your project</Button>
      <Button variant="secondary" size="lg" onClick={onReel}>
        Watch the reel <span style={{ marginLeft: 4 }}>→</span>
      </Button>
    </div>
  );
}

function HeroMeta() {
  return (
    <div className="hero-meta">
      {HERO_COPY.meta.map((m) => <span key={m}>{m}</span>)}
    </div>
  );
}

/* ---------- Spotlight ---------- */
function HeroSpotlight(props) {
  return (
    <header className="hero v-spotlight" id="top">
      <img className="hero-mark hero-spin" src="arperture/assets/arperture-mark.png" alt="" aria-hidden="true" />
      <div className="wrap">
        <div className="hero-inner">
          <div className="reveal d1"><Kicker>{HERO_COPY.kicker}</Kicker></div>
          <h1 className="hero-h1 reveal d2" style={{ marginTop: "var(--sp-5)" }}>{HERO_COPY.title}</h1>
          <p className="hero-lead reveal d3">{HERO_COPY.lead}</p>
          <div className="reveal d4"><HeroButtons {...props} /></div>
          <div className="reveal d4"><HeroMeta /></div>
        </div>
      </div>
    </header>
  );
}

/* ---------- Split ---------- */
function HeroSplit(props) {
  return (
    <header className="hero v-split" id="top">
      <div className="wrap">
        <div className="hero-inner">
          <div>
            <div className="reveal d1"><Kicker>{HERO_COPY.kicker}</Kicker></div>
            <h1 className="hero-h1 reveal d2" style={{ marginTop: "var(--sp-5)" }}>{HERO_COPY.title}</h1>
            <p className="hero-lead reveal d3">{HERO_COPY.lead}</p>
            <div className="reveal d4"><HeroButtons {...props} /></div>
            <div className="reveal d4"><HeroMeta /></div>
          </div>
          <button className="reel-card reveal d3" onClick={props.onReel} aria-label="Watch the reel">
            <img className="reel-spin hero-spin" src="arperture/assets/arperture-mark.png" alt="" aria-hidden="true" />
            <div className="reel-tc"><span className="rec"></span> REC · 00:14:22:08</div>
            <div className="reel-foot">
              <div>
                <div className="rf-title">Studio reel — 2026</div>
                <div className="rf-sub">Music video · Branded · Series</div>
              </div>
              <span className="reel-play"><Icon.play /></span>
            </div>
          </button>
        </div>
      </div>
    </header>
  );
}

/* ---------- Frame ---------- */
function HeroFrame(props) {
  return (
    <header className="hero v-frame" id="top">
      <div className="wrap">
        <div className="still reveal d2">
          <img className="still-spin hero-spin" src="arperture/assets/arperture-mark.png" alt="" aria-hidden="true" />
          <div className="still-tc">
            <span>SCENE 01 · TAKE 24</span>
            <span>● REC · 00:14:22:08</span>
          </div>
          <div className="still-inner">
            <div className="reveal d2"><Kicker>{HERO_COPY.kicker}</Kicker></div>
            <h1 className="hero-h1 reveal d3" style={{ marginTop: "var(--sp-4)" }}>{HERO_COPY.title}</h1>
            <p className="hero-lead reveal d4">{HERO_COPY.lead}</p>
            <div className="reveal d4"><HeroButtons {...props} /></div>
          </div>
        </div>
      </div>
    </header>
  );
}

function Hero({ variant = "spotlight", ...props }) {
  if (variant === "split") return <HeroSplit {...props} />;
  if (variant === "frame") return <HeroFrame {...props} />;
  return <HeroSpotlight {...props} />;
}

Object.assign(window, { Nav, Hero });
