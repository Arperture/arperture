/* Arperture landing — atoms + icon set */
const { useState, useRef, useEffect } = React;

function Mark({ size = 34, className = "", style = {} }) {
  return (
    <img
      src="arperture/assets/arperture-mark.png"
      alt="Arperture"
      width={size}
      height={size}
      className={className}
      style={{ display: "block", objectFit: "contain", ...style }}
    />
  );
}

function Kicker({ children, line = true }) {
  return <span className={"kicker" + (line ? " line" : "")}>{children}</span>;
}

function Button({ variant = "primary", size, children, onClick, disabled, type = "button", style }) {
  const cls = ["btn", "btn-" + variant, size ? "btn-" + size : ""].join(" ").trim();
  return (
    <button className={cls} onClick={onClick} disabled={disabled} type={type} style={style}>
      {children}
    </button>
  );
}

function Badge({ variant = "cyan", children }) {
  return <span className={"badge badge-" + variant}>{children}</span>;
}

/* ---------- icons (even-stroke line, 24px, currentColor) ---------- */
function Ic({ d, children, fill }) {
  return (
    <svg viewBox="0 0 24 24" fill={fill || "none"} stroke="currentColor"
      strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      {d ? <path d={d} /> : children}
    </svg>
  );
}
const Icon = {
  zap: () => <Ic d="M13 2 4.5 13.5H11l-1 8.5 8.5-11.5H12l1-8.5Z" />,
  film: () => (
    <Ic>
      <rect x="3" y="4" width="18" height="16" rx="2" />
      <path d="M7 4v16M17 4v16M3 9h4M3 15h4M17 9h4M17 15h4" />
    </Ic>
  ),
  spark: () => (
    <Ic>
      <path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5 18 18M18 6l-2.5 2.5M8.5 15.5 6 18" />
      <circle cx="12" cy="12" r="2.4" />
    </Ic>
  ),
  gem: () => (
    <Ic>
      <path d="M6 3h12l3 6-9 12L3 9l3-6Z" />
      <path d="M3 9h18M9 3 7 9l5 12M15 3l2 6-5 12" />
    </Ic>
  ),
  mail: () => (
    <Ic>
      <rect x="3" y="5" width="18" height="14" rx="2" />
      <path d="m4 7 8 6 8-6" />
    </Ic>
  ),
  pin: () => (
    <Ic>
      <path d="M20 10c0 5.5-8 11-8 11s-8-5.5-8-11a8 8 0 0 1 16 0Z" />
      <circle cx="12" cy="10" r="2.6" />
    </Ic>
  ),
  phone: () => <Ic d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L16 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2Z" />,
  calendar: () => (
    <Ic>
      <rect x="3" y="5" width="18" height="16" rx="2" />
      <path d="M3 9h18M8 3v4M16 3v4" />
    </Ic>
  ),
  play: () => <Ic fill="currentColor" d="M8 5v14l11-7z" />,
  arrow: () => <Ic d="M5 12h14M13 6l6 6-6 6" />,
};

Object.assign(window, { Mark, Kicker, Button, Badge, Icon });
