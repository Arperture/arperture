/* Arperture landing — Closing CTA, Contact form, Footer */

/* ============================================================
   CLOSING CTA
   ============================================================ */
function ClosingCTA({ onStart, onCall }) {
  return (
    <section className="section">
      <div className="wrap">
        <div className="cta-panel">
          <img className="cta-spin hero-spin" src="arperture/assets/arperture-mark.png" alt="" aria-hidden="true" />
          <div className="cta-inner">
            <Kicker line={false}>Roll camera</Kicker>
            <h2 style={{ marginTop: "var(--sp-4)" }}>
              Ready to create something <em>extraordinary?</em>
            </h2>
            <p>
              Tell us about the story. We'll come back with a treatment, a look, and a timeline —
              usually within a day.
            </p>
            <div className="btn-row">
              <Button variant="coral" size="lg" onClick={onStart}>Start your project</Button>
              <Button variant="secondary" size="lg" onClick={onCall}>Book a discovery call</Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ============================================================
   CONTACT
   ============================================================ */
const PROJECT_TYPES = ["Music video", "Brand / DTC", "Cinematic short", "Series", "Other"];

function Contact({ formRef }) {
  const [form, setForm] = useState({ name: "", email: "", brief: "" });
  const [type, setType] = useState("Music video");
  const [errors, setErrors] = useState({});
  const [sent, setSent] = useState(false);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = (e) => {
    e.preventDefault();
    const er = {};
    if (!form.name.trim()) er.name = "Tell us who you are.";
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(form.email)) er.email = "A valid email, please.";
    if (form.brief.trim().length < 12) er.brief = "A line or two about the story.";
    setErrors(er);
    if (Object.keys(er).length === 0) setSent(true);
  };

  const reset = () => { setForm({ name: "", email: "", brief: "" }); setType("Music video"); setErrors({}); setSent(false); };

  return (
    <section className="section contact" id="contact" ref={formRef}>
      <div className="wrap">
        <div className="contact-grid">
          <div>
            <Kicker>05 — Let's create together</Kicker>
            <h2>Tell us about the story.</h2>
            <p className="contact-lead">
              Brands, artists & storytellers — send the brief and we'll roll camera. We read every one.
            </p>
            <ul className="contact-list">
              <li>
                <span className="ci"><Icon.mail /></span>
                <div>
                  <div className="cl">Email</div>
                  <a className="cv" href="mailto:hello@arperture.io">hello@arperture.io</a>
                </div>
              </li>
              <li>
                <span className="ci"><Icon.pin /></span>
                <div>
                  <div className="cl">Studio</div>
                  <div className="cv">Arcola, Virginia</div>
                </div>
              </li>
              <li>
                <span className="ci"><Icon.calendar /></span>
                <div>
                  <div className="cl">Availability</div>
                  <div className="cv">● Now booking · Q3 2026</div>
                </div>
              </li>
            </ul>
          </div>

          <div className="contact-form">
            {sent ? (
              <div>
                <div className="alert alert-success" style={{ marginBottom: "var(--sp-5)" }}>
                  <span className="dot"></span>
                  <div>
                    <strong>Brief received.</strong> We'll come back with a treatment and a timeline — usually within a day.
                  </div>
                </div>
                <Button variant="secondary" onClick={reset}>Send another brief</Button>
              </div>
            ) : (
              <form onSubmit={submit} noValidate>
                <div className="form-2col">
                  <div className={"field" + (errors.name ? " error" : "")}>
                    <label>Name</label>
                    <input type="text" placeholder="Your name" value={form.name} onChange={set("name")} />
                    {errors.name && <div className="hint">{errors.name}</div>}
                  </div>
                  <div className={"field" + (errors.email ? " error" : "")}>
                    <label>Email</label>
                    <input type="email" placeholder="you@studio.com" value={form.email} onChange={set("email")} />
                    {errors.email && <div className="hint">{errors.email}</div>}
                  </div>
                </div>

                <div className="field">
                  <label className="field-label">Project type</label>
                  <div className="chips">
                    {PROJECT_TYPES.map((t) => (
                      <button type="button" key={t} className={"chip" + (type === t ? " on" : "")} onClick={() => setType(t)}>
                        {t}
                      </button>
                    ))}
                  </div>
                </div>

                <div className={"field" + (errors.brief ? " error" : "")}>
                  <label>The brief</label>
                  <textarea rows={4} placeholder="The story, the vibe, references, timeline…" value={form.brief} onChange={set("brief")} />
                  {errors.brief && <div className="hint">{errors.brief}</div>}
                </div>

                <div className="btn-row" style={{ marginTop: "var(--sp-2)" }}>
                  <Button variant="coral" size="lg" type="submit">Send the brief →</Button>
                  <span style={{ fontFamily: "var(--font-mono)", fontSize: "var(--text-xs)", letterSpacing: ".1em", color: "var(--text-faint)" }}>
                    24-hour reply
                  </span>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}

/* ============================================================
   FOOTER
   ============================================================ */
function Footer({ onNav }) {
  const cols = [
    ["Studio", ["What we make", "Why us", "Process", "Selected work"]],
    ["Company", ["About", "Careers", "Press", "Contact"]],
    ["Connect", ["Instagram", "YouTube", "Vimeo", "LinkedIn"]],
  ];
  return (
    <footer className="footer">
      <div className="wrap">
        <div className="foot-top">
          <div className="foot-brand">
            <a className="brand" href="#top" onClick={(e) => { e.preventDefault(); window.scrollTo({ top: 0, behavior: "smooth" }); }}>
              <Mark size={32} />
              <span className="brand-name">Arperture<b>.</b></span>
            </a>
            <p>Cinematic AI video for brands, artists & storytellers. Composed in the dark, delivered as masters.</p>
          </div>
          {cols.map(([h, items]) => (
            <div className="foot-col" key={h}>
              <h5>{h}</h5>
              <ul>{items.map((i) => <li key={i}><a>{i}</a></li>)}</ul>
            </div>
          ))}
        </div>
        <div className="foot-base">
          <span>© 2026 Arperture Media · Arcola, VA</span>
          <span>Cinematic AI, shot through the aperture.</span>
        </div>
      </div>
    </footer>
  );
}

Object.assign(window, { ClosingCTA, Contact, Footer });
