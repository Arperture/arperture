/* Arperture landing — Services, Why, How It Works, Work grid + modal */

/* ============================================================
   WHAT WE CREATE
   ============================================================ */
const SERVICES = [
  {
    no: "01", title: "AI Music Videos", grad: "var(--grad-spectrum)",
    body: "Scroll-stopping music videos generated shot-by-shot and cut to your track's tempo map — one continuous mood, start to finish.",
    tags: ["Veo 3.1", "Beat-synced", "Color grade"],
  },
  {
    no: "02", title: "Brand Stories", grad: "var(--grad-dusk)",
    body: "DTC spots and brand films with consistent characters and a cinematic eye — the look of a production house, at the speed of a prompt.",
    tags: ["DTC spots", "Character lock", "Sound design"],
  },
  {
    no: "03", title: "Cinematic Shorts", grad: "var(--grad-signal)",
    body: "Original episodic shorts and narrative pieces — concept to delivered master, directed and scored like a film, not a feed.",
    tags: ["Episodic", "Narrative", "Master delivery"],
  },
];

function Services() {
  return (
    <section className="section" id="work">
      <div className="wrap">
        <div className="section-head">
          <Kicker>01 — What we make</Kicker>
          <h2 className="section-title">Three ways to roll camera.</h2>
          <p className="section-sub">
            Every project is generated, directed, scored, and delivered as a finished master —
            not a stock clip, a frame.
          </p>
        </div>
        <div className="svc-grid">
          {SERVICES.map((s) => (
            <article className="svc-card" key={s.no}>
              <div className="svc-thumb" style={{ background: s.grad }}>
                <span className="svc-no">{s.no} / 03</span>
                <img className="svc-spin" src="arperture/assets/arperture-mark.png" alt="" aria-hidden="true" />
              </div>
              <div className="svc-body">
                <h3>{s.title}</h3>
                <p>{s.body}</p>
                <div className="svc-tags">
                  {s.tags.map((t) => <span className="svc-tag" key={t}>{t}</span>)}
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ============================================================
   WHY CHOOSE ARPERTURE
   ============================================================ */
const WHY = [
  { no: "01", icon: "zap", title: "Lightning fast", body: "Script to delivered cut in days, not months. The render queue never sleeps." },
  { no: "02", icon: "film", title: "Cinematic quality", body: "Graded, lit, and composed in the dark — every frame holds up on the big screen." },
  { no: "03", icon: "spark", title: "Endlessly creative", body: "No location, cast, or budget ceiling. If you can describe it, we can shoot it." },
  { no: "04", icon: "gem", title: "Boutique approach", body: "A small studio with a human director on every project. You talk to the people who make it." },
];

function Why() {
  return (
    <section className="section" id="why">
      <div className="wrap">
        <div className="section-head">
          <Kicker>02 — Why Arperture</Kicker>
          <h2 className="section-title">A production house in a black box.</h2>
          <p className="section-sub">
            The speed of generative video, with the taste and restraint of a real studio behind it.
          </p>
        </div>
        <div className="why-grid">
          {WHY.map((w) => {
            const Glyph = Icon[w.icon];
            return (
              <article className="why-card" key={w.no}>
                <div className="why-ic"><Glyph /></div>
                <div>
                  <span className="why-no">{w.no}</span>
                  <h4>{w.title}</h4>
                  <p>{w.body}</p>
                </div>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}

/* ============================================================
   HOW IT WORKS
   ============================================================ */
const STEPS = [
  { no: "01", title: "Discovery", body: "Tell us about the story. We pin down tone, references, and the shape of the cut." },
  { no: "02", title: "Concept", body: "We board the shots and lock a look — prompt grammar, grade, and sound direction." },
  { no: "03", title: "Production", body: "Shots are generated, directed, and assembled, then scored and sound-designed." },
  { no: "04", title: "Delivery", body: "Final master uploaded to your drive, in the formats and crops you need." },
];

function How() {
  return (
    <section className="section" id="how">
      <div className="wrap">
        <div className="section-head">
          <Kicker>03 — How it works</Kicker>
          <h2 className="section-title">From script to screen in four moves.</h2>
        </div>
        <div className="steps">
          {STEPS.map((s) => (
            <div className="step" key={s.no}>
              <div className="step-node">{s.no}</div>
              <span className="step-no">Phase {s.no}</span>
              <h4>{s.title}</h4>
              <p>{s.body}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ============================================================
   FEATURED WORK (grid + modal)
   ============================================================ */
const WORK = [
  { id: "late-fee", title: "Late Fee", category: "Music Video", badge: "cyan", grad: "var(--grad-spectrum)", client: "The Delta Pines", year: "2025",
    blurb: "46-shot road narrative generated in Veo 3.1, cut to a single-take feel.",
    detail: "A nocturnal highway story for indie band The Delta Pines. Every shot was generated and graded to hold one continuous mood — headlights, motel neon, and the long dark between towns — then scored to the track's tempo map.",
    stats: [["46", "Shots"], ["3", "Days, script→cut"], ["2K", "Master"]] },
  { id: "ten-hours", title: "10 Extra Hours", category: "Branded", badge: "coral", grad: "var(--grad-dusk)", client: "Northbound DTC", year: "2025",
    blurb: "DTC spot with a consistent character across an 8-shot sitcom cut.",
    detail: "A direct-to-consumer spot built like a mini sitcom. The challenge was character consistency across eight shots and two locations — solved with locked reference frames and a tuned prompt grammar so the lead reads as the same person every time.",
    stats: [["8", "Shots"], ["1", "Hero character"], ["00:30", "Runtime"]] },
  { id: "day-with-death", title: "A Day with Death", category: "Series", badge: "purple", grad: "var(--grad-signal)", client: "Original", year: "2024",
    blurb: "Surreal episodic short — the Reaper running errands in suburbia.",
    detail: "An original episodic concept: Death, in a hoodie, doing mundane suburban chores. Deadpan framing, warm grade, and a restrained sound design sell the absurdity without a single line of dialogue.",
    stats: [["4", "Episodes"], ["12", "Locations"], ["B&W→Warm", "Grade"]] },
  { id: "signal-loss", title: "Signal Loss", category: "Music Video", badge: "cyan", grad: "var(--grad-dusk)", client: "KAIRO", year: "2025",
    blurb: "Glitch-driven performance piece, fully generated crowd and stage.",
    detail: "A performance video where the venue, crowd, and lighting rig are all generated. Intentional signal-loss artifacts are used as transitions, syncing dropouts to the track's hits.",
    stats: [["31", "Shots"], ["1", "Generated venue"], ["2.5K", "Master"]] },
  { id: "the-commute", title: "The Commute", category: "Branded", badge: "coral", grad: "var(--grad-spectrum)", client: "Meridian Rail", year: "2024",
    blurb: "Quiet, cinematic transit brand film — dawn to dusk in one ride.",
    detail: "A calm brand film for a rail operator, compressing a full day into a single ride. Soft natural light, slow push-ins, and a score that breathes — proof the system can do restraint, not just spectacle.",
    stats: [["18", "Shots"], ["1", "Continuous ride"], ["00:60", "Runtime"]] },
  { id: "reaper-faq", title: "Reaper FAQ", category: "Series", badge: "purple", grad: "var(--grad-signal)", client: "Original", year: "2025",
    blurb: "Spin-off shorts — Death answers viewer questions, deadpan.",
    detail: "A short-form spin-off from A Day with Death. Each clip is a single locked shot of the Reaper answering a viewer question, leaning on timing and sound rather than motion.",
    stats: [["9", "Shorts"], ["1", "Shot each"], ["Vertical", "Format"]] },
];

function WorkCard({ item, onOpen }) {
  return (
    <button className="card" onClick={() => onOpen(item)}>
      <div className="thumb" style={{ background: item.grad }}>
        <span className="play"><Icon.play /></span>
      </div>
      <div className="cbody">
        <Badge variant={item.badge}>{item.category}</Badge>
        <h4>{item.title}</h4>
        <p>{item.blurb}</p>
        <span className="meta">{item.client} · {item.year}</span>
      </div>
    </button>
  );
}

function WorkGrid({ onOpen }) {
  return (
    <section className="section" id="selected">
      <div className="wrap">
        <div className="work-head">
          <div>
            <Kicker>04 — Selected work</Kicker>
            <h2>Frames we've shot through the aperture.</h2>
          </div>
          <p className="section-sub" style={{ marginBottom: 4 }}>
            Open any frame for the breakdown — shots, runtime, and how it was made.
          </p>
        </div>
        <div className="work-grid">
          {WORK.map((w) => <WorkCard key={w.id} item={w} onOpen={onOpen} />)}
        </div>
      </div>
    </section>
  );
}

function CaseStudyModal({ item, onClose, onStart }) {
  useEffect(() => {
    const h = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [onClose]);
  if (!item) return null;
  return (
    <div className="scrim" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <button className="closex" onClick={onClose} aria-label="Close">✕</button>
        <div className="mhead" style={{ background: item.grad }}>
          <div className="hrow">
            <Badge variant={item.badge}>{item.category}</Badge>
            <Badge variant="cyan">● Veo 3.1</Badge>
          </div>
        </div>
        <div className="mbody">
          <h3>{item.title}</h3>
          <p style={{ fontFamily: "var(--font-mono)", fontSize: "var(--text-xs)", letterSpacing: ".1em", textTransform: "uppercase", color: "var(--text-faint)", marginBottom: "var(--sp-4)" }}>
            {item.client} · {item.year}
          </p>
          <p>{item.detail}</p>
          <div className="stat-row">
            {item.stats.map(([n, l]) => (
              <div className="stat" key={l}>
                <div className="n">{n}</div>
                <div className="l">{l}</div>
              </div>
            ))}
          </div>
          <div className="btn-row" style={{ marginTop: "var(--sp-6)" }}>
            <Button variant="primary" onClick={onClose}>▶ Play reel</Button>
            <Button variant="coral" onClick={() => { onClose(); onStart(); }}>Start a project like this</Button>
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { Services, Why, How, WorkGrid, CaseStudyModal, WORK });
