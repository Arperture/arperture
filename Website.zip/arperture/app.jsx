/* Arperture landing — app assembly + tweaks */

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "heroLayout": "spotlight",
  "backdrop": "Ink",
  "headingFont": "Clash",
  "atmosphere": 55
}/*EDITMODE-END*/;

const BACKDROPS = { "Black": "#000000", "Ink": "var(--ink-950)", "Charcoal": "var(--ink-900)" };
const HEAD_FONTS = {
  "Clash": "'Clash Display','Hanken Grotesk',sans-serif",
  "Hanken": "'Hanken Grotesk',system-ui,sans-serif",
  "Mono": "'Space Mono',ui-monospace,monospace",
};

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [active, setActive] = useState(null);
  const contactRef = useRef(null);

  // entrance animation only when foregrounded
  useEffect(() => {
    const id = requestAnimationFrame(() => document.body.classList.add("reveal-anim"));
    return () => cancelAnimationFrame(id);
  }, []);

  // apply tweak-driven CSS variables on <html>
  useEffect(() => {
    const r = document.documentElement.style;
    r.setProperty("--page-bg", BACKDROPS[t.backdrop] || "var(--ink-950)");
    r.setProperty("--heading-font", HEAD_FONTS[t.headingFont] || HEAD_FONTS.Clash);
    const a = (t.atmosphere ?? 55) / 100;
    r.setProperty("--grain-opacity", (a * 0.09).toFixed(3));   // 0 → .09
    r.setProperty("--bloom-opacity", (0.25 + a * 1.05).toFixed(3)); // .25 → 1.3
  }, [t.backdrop, t.headingFont, t.atmosphere]);

  const toContact = () => {
    const el = contactRef.current;
    if (el) window.scrollTo({ top: el.offsetTop - 70, behavior: "smooth" });
  };
  const toWork = () => {
    const el = document.getElementById("selected");
    if (el) window.scrollTo({ top: el.offsetTop - 70, behavior: "smooth" });
  };

  return (
    <>
      <Nav onStart={toContact} />
      <Hero variant={t.heroLayout} onStart={toContact} onReel={toWork} />
      <Services />
      <Why />
      <How />
      <WorkGrid onOpen={setActive} />
      <ClosingCTA onStart={toContact} onCall={toContact} />
      <Contact formRef={contactRef} />
      <Footer />
      <CaseStudyModal item={active} onClose={() => setActive(null)} onStart={toContact} />

      <TweaksPanel>
        <TweakSection label="Hero" />
        <TweakRadio label="Layout" value={t.heroLayout}
          options={["spotlight", "split", "frame"]}
          onChange={(v) => setTweak("heroLayout", v)} />
        <TweakSection label="Atmosphere" />
        <TweakRadio label="Backdrop" value={t.backdrop}
          options={["Black", "Ink", "Charcoal"]}
          onChange={(v) => setTweak("backdrop", v)} />
        <TweakSlider label="Grain & glow" value={t.atmosphere} min={0} max={100} unit="%"
          onChange={(v) => setTweak("atmosphere", v)} />
        <TweakSection label="Type" />
        <TweakRadio label="Headings" value={t.headingFont}
          options={["Clash", "Hanken", "Mono"]}
          onChange={(v) => setTweak("headingFont", v)} />
      </TweaksPanel>
    </>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
